/**
 * 
 */
package com.hacker.rank.prog.OOP;

/**
 * @author aprasa03
 *
 */
public class BaseClass {
	private void print()
	{
		System.out.println("print From Class B");
	}

}

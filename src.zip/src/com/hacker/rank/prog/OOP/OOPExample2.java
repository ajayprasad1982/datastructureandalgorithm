package com.hacker.rank.prog.OOP;

public class OOPExample2 {

	public static void main(String[] args) {
		A x=new A();
		B y =new B();
		C z=new C();
		//z=x;
		
	}
	
	

}

class A
{
	
}
class B extends A
{
	
}
class C extends A
{
	
}
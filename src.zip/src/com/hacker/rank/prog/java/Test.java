package com.hacker.rank.prog.java;

import java.io.IOException;
import java.io.InvalidObjectException;
import java.util.ArrayList;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		List<String> col1= new ArrayList<String>();
		
		List<String> col2= new ArrayList<String>();
		
		col1.add("A");col1.add("B");col1.add("C");
		col2.add("A");col2.add("B");
		//list.a
		
	}

}

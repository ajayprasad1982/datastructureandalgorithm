/**
 * 
 */
package com.hacker.rank.prog.LinkedList;

/**
 * @author aprasa03
 *
 */
public class SortLinkedListWithPartialList {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Node node = new Node();
		int a[] = { 1, 3, 5, 2, 4, 6, 7, 8 };

		for (int i : a) {
			node.insert(i);
		}

		node.display();
		System.out.println(node.getHead().getData());
		
	Node head=	sort(node.getHead());
	node.display(head);
		
	}
public static Node sort(Node head)
{
	Node node1=head;
	Node node2=null;
	Node result=null;
	while(head!=null)
	{
		
		if(node1.getNext()!=null && node1.getData()>node1.getNext().getData())
		{
			node2=node1.getNext();
			node1.setNext(null);
			break;
		}
		node1=node1.getNext();
	}
	node1=head;
	if(node2==null) return node1;
	
	while(node1!=null && node2!=null)
	{
		if(node1.getData()<=node2.getData())
		{
			if(result==null)
			{
				result=node1;
			}
			node1=swap(node1,node2);
		}
		else
		{
			if(result==null)
			{
				result=node2;
				
			}
			node2=swap(node2,node1);
	}
	}
	return result;
}
	
private static Node swap(Node node,Node node1)
{
	Node temp=node.getNext();
	node.setNext(node1);
	node=temp;
	return node;
}

}

/**
 * 
 */
package com.hacker.rank.prog.misc;

/**
 * @author aprasa03
 *
 */
public class AddTwoVeryBigNumbers {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String num1="999999";
		String num2="1111111";
		add(num1, num2);

	}
private static void add(String num1,String num2)
{
	
	int max=Math.max(num1.length(), num2.length());
	
	int [] n1=new int[max];
	int [] n2=new int[max];
	int k=0;
	for(int i=num1.length()-1;i>=0;i--)
	{
		n1[k++]=num1.codePointAt(i)-48;
	}
	k=0;
	for(int i=num2.length()-1;i>=0;i--)
	{
		n2[k++]=num2.codePointAt(i)-48;
	}
	k=0;
	int sum[]=new int[max+1];
	int carry=0;
	for(k=0;k<max;k++)
	{
		int num=n1[k]+n2[k]+carry;
		sum[k]=num%10;
		if(num>=10)
		{
			carry=1;
		}
		else
		{
			carry=0;
		}
		
	}
	sum[max]=carry;
	
	for(int i=max;i>=0;i--)
	{
		System.out.print(sum[i]);
	}
	
}
	

}
